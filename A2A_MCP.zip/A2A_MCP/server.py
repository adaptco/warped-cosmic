"""
A2A_MCP — Agent-to-Agent MCP Server  v1.0.0
Usage:
  stdio (default):      python server.py
  streamable-http:      python server.py --http
  SSE:                  python server.py --sse
"""
import os, sys, json, hashlib, hmac
from datetime import datetime, timezone
from typing import Any
import httpx
from mcp.server.fastmcp import FastMCP

mcp = FastMCP(
    name="A2A_MCP",
    instructions="A2A orchestration server: task graph CRUD, RASIC lookup, A2A envelope relay, MoE agent selection, Luma quality gate, Airtable sync, Slack notify.",
    host="0.0.0.0",
    port=int(os.getenv("PORT", "8000")),
)

BASE_DIR      = os.path.dirname(os.path.abspath(__file__))
GRAPH_PATH    = os.path.join(BASE_DIR, "task-graph.a2a.json")
RASIC_PATH    = os.path.join(BASE_DIR, "rasic-matrix.json")
REGISTRY_PATH = os.path.join(BASE_DIR, "mcp-registry.json")
ARTIFACTS_DIR = os.path.join(BASE_DIR, "artifacts")
RECEIPTS_DIR  = os.path.join(BASE_DIR, "receipts")
for d in (ARTIFACTS_DIR, RECEIPTS_DIR): os.makedirs(d, exist_ok=True)

AIRTABLE_BASE_ID  = os.getenv("AIRTABLE_BASE_ID", "appevPR8B4uJwfQdR")
AIRTABLE_API_KEY  = os.getenv("AIRTABLE_API_KEY", "")
ECHO_RELAY_SECRET = os.getenv("ECHO_RELAY_SECRET", "")
SLACK_WEBHOOK_URL = os.getenv("SLACK_WEBHOOK_URL", "")

def _load(p): 
    with open(p) as f: return json.load(f)
def _save(p, d):
    with open(p,"w") as f: json.dump(d,f,indent=2)
def _now(): return datetime.now(timezone.utc).isoformat()
def _sign(payload):
    if not ECHO_RELAY_SECRET: return "unsigned"
    return hmac.new(ECHO_RELAY_SECRET.encode(), payload.encode(), hashlib.sha256).hexdigest()

# ── Tools ─────────────────────────────────────────────────────────────────────

@mcp.tool()
def get_task_graph() -> dict:
    """Return the full A2A task graph DAG."""
    return _load(GRAPH_PATH)

@mcp.tool()
def get_task(task_id: str) -> dict:
    """Fetch a single task node by ID (e.g. T-001)."""
    tasks = _load(GRAPH_PATH).get("tasks", [])
    for t in tasks:
        if t["task_id"] == task_id: return t
    return {"error": f"Task {task_id} not found", "available": [t["task_id"] for t in tasks]}

@mcp.tool()
def update_task_status(task_id: str, status: str, agent: str = "system") -> dict:
    """Update a task's live status. status ∈ {pending,active,complete,blocked,failed}"""
    VALID = {"pending","active","complete","blocked","failed"}
    if status not in VALID: return {"error": f"Invalid status. Must be one of {VALID}"}
    graph = _load(GRAPH_PATH)
    for t in graph.get("tasks",[]):
        if t["task_id"] == task_id:
            t["status"] = status; t["updated_at"] = _now(); t["updated_by"] = agent
            _save(GRAPH_PATH, graph)
            return {"task_id": task_id, "status": status, "updated_at": t["updated_at"]}
    return {"error": f"Task {task_id} not found"}

@mcp.tool()
def get_rasic_matrix(task_id: str = "") -> dict:
    """Return the full RASIC matrix, or a single task row if task_id given."""
    matrix = _load(RASIC_PATH)
    if task_id:
        row = matrix.get("tasks",{}).get(task_id)
        return {task_id: row} if row else {"error": f"No RASIC row for {task_id}"}
    return matrix

@mcp.tool()
def get_agent_card(agent_name: str) -> dict:
    """Return agent card for Claude|GPT-4o|Gemini|Vertex|Echo|Luma|Dot."""
    registry = _load(REGISTRY_PATH)
    agents = {a["name"]: a for a in registry.get("agents",[])}
    if agent_name not in agents:
        return {"error": f"Agent '{agent_name}' not found", "available": list(agents.keys())}
    return agents[agent_name]

@mcp.tool()
def list_agents(filter_status: str = "") -> list:
    """List all registered agents. Optional filter: active|relay|pending."""
    agents = _load(REGISTRY_PATH).get("agents",[])
    return [a for a in agents if a.get("status") == filter_status] if filter_status else agents

@mcp.tool()
async def emit_a2a_envelope(task_id: str, from_agent: str, to_agent: str,
                             artifact_id: str, data: dict, llm_hop: str = "claude→any") -> dict:
    """Fire a signed A2A envelope via Echo relay. Logs hop and POSTs to target webhook."""
    envelope = {
        "envelope_version":"1.0", "task_id":task_id, "from_agent":from_agent,
        "to_agent":to_agent, "llm_hop":llm_hop,
        "payload":{"artifact_id":artifact_id,"data":data},
        "timestamp":_now(), "signature":None,
    }
    envelope["signature"] = _sign(json.dumps(envelope, sort_keys=True))
    log_path = os.path.join(ARTIFACTS_DIR, "echo-relay-log.jsonl")
    with open(log_path,"a") as f: f.write(json.dumps(envelope)+"\n")
    registry = _load(REGISTRY_PATH)
    agents = {a["name"]:a for a in registry.get("agents",[])}
    webhook = agents.get(to_agent,{}).get("webhook_endpoint","")
    status = "logged"
    if webhook and webhook.startswith("http"):
        try:
            async with httpx.AsyncClient(timeout=10) as c:
                r = await c.post(webhook, json=envelope)
            status = f"delivered:{r.status_code}"
        except Exception as e: status = f"failed:{e}"
    return {"envelope_id": envelope["signature"][:16], "status": status, "hop": llm_hop}

@mcp.tool()
async def moe_select_agent(task_scope: str) -> dict:
    """
    Select optimal agent for task_scope via Airtable MoE, or static fallback.
    task_scope ∈ {scaffold,arch_enforce,code_write,mcp_call,chat,mobile,ui-gen,ux,wasm,relay,audit}
    """
    STATIC = {
        "scaffold":{"agent":"Claude","model":"claude-sonnet-4-20250514","weight":35},
        "arch_enforce":{"agent":"Claude","model":"claude-sonnet-4-20250514","weight":35},
        "code_write":{"agent":"Claude","model":"claude-sonnet-4-20250514","weight":35},
        "mcp_call":{"agent":"Claude","model":"claude-sonnet-4-20250514","weight":35},
        "chat":{"agent":"GPT-4o","model":"gpt-4o","weight":25},
        "mobile":{"agent":"GPT-4o","model":"gpt-4o","weight":25},
        "ui-gen":{"agent":"Gemini Pro","model":"gemini-2.0-flash","weight":25},
        "ux":{"agent":"Vertex AI","model":"text-bison@002","weight":15},
        "wasm":{"agent":"Vertex AI","model":"text-bison@002","weight":15},
        "relay":{"agent":"Echo","model":"any","weight":0},
        "audit":{"agent":"Luma","model":"any","weight":0},
    }
    if not AIRTABLE_API_KEY:
        return {"selected":STATIC.get(task_scope,STATIC["scaffold"]),"source":"static_fallback","task_scope":task_scope}
    url = f"https://api.airtable.com/v0/{AIRTABLE_BASE_ID}/Agents"
    headers = {"Authorization":f"Bearer {AIRTABLE_API_KEY}"}
    params = {"filterByFormula":f"AND({{Active}}=1,FIND('{task_scope}',ARRAYJOIN({{Tools Enabled}},',')))","maxRecords":10}
    try:
        async with httpx.AsyncClient(timeout=10) as c:
            resp = await c.get(url, headers=headers, params=params)
        records = resp.json().get("records",[])
        if not records: return {"selected":STATIC.get(task_scope,STATIC["scaffold"]),"source":"airtable_empty_fallback","task_scope":task_scope}
        best = max(records, key=lambda r: len(r["fields"].get("Tools Enabled",[])))
        f = best["fields"]
        return {"selected":{"agent":f.get("Agent Name"),"agent_id":f.get("Agent ID"),"tools":f.get("Tools Enabled",[])},"source":"airtable_live","task_scope":task_scope,"record_id":best["id"]}
    except Exception as e: return {"error":str(e),"task_scope":task_scope}

@mcp.tool()
def run_luma_gate(task_id: str, total_tokens: int, consumed_tokens: int,
                  coherence_score: float, artifact_hashes: dict) -> dict:
    """
    Luma quality gate: PASS requires coverage==100% AND coherence>=0.72.
    Writes signed receipt to receipts/. Returns blocking=True on FAIL.
    """
    pct    = round((consumed_tokens/total_tokens*100),2) if total_tokens else 0
    passed = (pct >= 100.0) and (coherence_score >= 0.72)
    receipt = {
        "task_id":task_id,"timestamp":_now(),
        "coverage":{"total_tokens":total_tokens,"consumed_tokens":consumed_tokens,"coverage_pct":pct},
        "coherence":{"coherence_score":round(coherence_score,4),"threshold":0.72,"passed":coherence_score>=0.72},
        "gate":"PASS" if passed else "FAIL","artifact_hashes":artifact_hashes,
        "signature":"Ed25519:PENDING","signed_by":"Luma",
    }
    path = os.path.join(RECEIPTS_DIR, f"{task_id}-luma.receipt.json")
    _save(path, receipt)
    return {"gate":receipt["gate"],"coverage_pct":pct,"coherence_score":coherence_score,"receipt_path":path,"blocking":not passed}

@mcp.tool()
async def sync_to_airtable(task_id: str, status: str, agent: str = "system", tokens: int = 0) -> dict:
    """Mirror task status to CCMC Agent Ops Airtable. Skips if AIRTABLE_API_KEY not set."""
    if not AIRTABLE_API_KEY: return {"skipped":True,"reason":"AIRTABLE_API_KEY not set"}
    MAP = {"active":"In Progress","complete":"Done","blocked":"Blocked","failed":"Blocked","pending":"Backlog"}
    airtable_status = MAP.get(status,"Backlog")
    base_url = f"https://api.airtable.com/v0/{AIRTABLE_BASE_ID}/Tasks"
    headers  = {"Authorization":f"Bearer {AIRTABLE_API_KEY}","Content-Type":"application/json"}
    try:
        async with httpx.AsyncClient(timeout=10) as c:
            s = await c.get(base_url, headers=headers, params={"filterByFormula":f"{{Task ID}}='{task_id}'","maxRecords":1})
            recs = s.json().get("records",[])
            if not recs: return {"error":f"Task {task_id} not found in Airtable"}
            rid = recs[0]["id"]
            p = await c.patch(f"{base_url}/{rid}", headers=headers, json={"fields":{"Status":airtable_status}})
        return {"synced":True,"task_id":task_id,"airtable_status":airtable_status,"record_id":rid,"http_status":p.status_code}
    except Exception as e: return {"error":str(e),"task_id":task_id}

@mcp.tool()
async def notify_slack(message: str, task_id: str = "", level: str = "info") -> dict:
    """Post to Slack #all-adaptco. level ∈ {info,success,warning,error}. Skips if no webhook."""
    if not SLACK_WEBHOOK_URL: return {"skipped":True,"reason":"SLACK_WEBHOOK_URL not set"}
    icon = {"info":"ℹ️","success":"✅","warning":"⚠️","error":"🚨"}.get(level,"ℹ️")
    prefix = f"{icon} *A2A_MCP* `{task_id}`" if task_id else f"{icon} *A2A_MCP*"
    payload = {"blocks":[
        {"type":"header","text":{"type":"plain_text","text":"A2A Pipeline Update"}},
        {"type":"section","text":{"type":"mrkdwn","text":f"{prefix}\n{message}"}},
        {"type":"context","elements":[{"type":"mrkdwn","text":f"_{_now()}_"}]},
    ]}
    try:
        async with httpx.AsyncClient(timeout=10) as c:
            r = await c.post(SLACK_WEBHOOK_URL, json=payload)
        return {"sent":True,"status_code":r.status_code}
    except Exception as e: return {"error":str(e)}

@mcp.tool()
def get_pipeline_status() -> dict:
    """Live pipeline snapshot: all task statuses, completion %, gate receipts."""
    tasks = _load(GRAPH_PATH).get("tasks",[])
    counts: dict = {}
    for t in tasks:
        s = t.get("status","pending"); counts[s] = counts.get(s,0)+1
    receipts = []
    for f in os.listdir(RECEIPTS_DIR):
        if f.endswith(".receipt.json"):
            r = _load(os.path.join(RECEIPTS_DIR,f)); receipts.append({"task":r["task_id"],"gate":r["gate"]})
    done = counts.get("complete",0)
    return {
        "pipeline":"A2A_MCP","timestamp":_now(),"task_counts":counts,
        "total_tasks":len(tasks),"completion_pct":round(done/len(tasks)*100,1) if tasks else 0,
        "receipts":receipts,
        "tasks":[{"id":t["task_id"],"name":t["name"],"status":t.get("status","pending")} for t in tasks],
    }

# ─── Entry ────────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    transport = "stdio"
    if "--http" in sys.argv: transport = "streamable-http"
    elif "--sse"  in sys.argv: transport = "sse"
    mcp.run(transport=transport)
