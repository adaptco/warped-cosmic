# A2A_MCP — Agent-to-Agent MCP Server

Sovereign MoA pipeline orchestrating **10 A2A tasks** across Claude, GPT-4o, Gemini, Vertex AI, Echo, Luma, and Dot — served as a **FastMCP server** with live Airtable sync, HMAC-signed relay envelopes, and Luma quality attestation.

## Quick Start

```bash
pip install -r requirements.txt
cp .env.example .env   # fill in your keys

# stdio (Claude Desktop / MCP clients)
python server.py

# HTTP (streamable-http, port 8000)
python server.py --http

# SSE
python server.py --sse
```

## 12 MCP Tools

| Tool | Description |
|------|-------------|
| `get_task_graph` | Full 10-node A2A DAG |
| `get_task` | Single task by ID |
| `update_task_status` | Live status update |
| `get_rasic_matrix` | RASIC row for any task |
| `get_agent_card` | Agent config + tools |
| `list_agents` | All registered agents |
| `emit_a2a_envelope` | HMAC-signed relay hop |
| `moe_select_agent` | Airtable MoE selection |
| `run_luma_gate` | Coverage + coherence gate |
| `sync_to_airtable` | Mirror status to CCMC base |
| `notify_slack` | Post to #all-adaptco |
| `get_pipeline_status` | Live pipeline snapshot |

## Pipeline (10 Tasks)

```
T-001 Browser Script  →  T-002 MCP Dispatch  →  T-003 MoE Select
T-003                 →  T-004 MoA Handoff   →  T-005 Webhook Notify
T-005                 →  T-006 PM Tasks [HITL]→  T-007 Scaffold Gen
T-007                 →  T-008 Zapier Jobs   →  T-009 Gemini UI
T-009                 →  T-010 Vertex+WASM+Deploy (Luma gate)
```

## Architecture

- **Echo** relays all cross-LLM envelopes (HMAC-SHA256 signed)
- **Luma** gates T-010 — blocks if coverage < 100% or coherence < 0.72
- **Airtable CCMC Agent Ops** (`appevPR8B4uJwfQdR`) is the SSOT for agent registry
- **GitHub Actions** orchestrates every task via matrix dispatch

## Environment Variables

| Variable | Required | Description |
|----------|----------|-------------|
| `AIRTABLE_API_KEY` | ✓ for live MoE | Personal access token |
| `AIRTABLE_BASE_ID` | default set | `appevPR8B4uJwfQdR` |
| `ECHO_RELAY_SECRET` | ✓ for signed envelopes | 32+ char secret |
| `SLACK_WEBHOOK_URL` | ✓ for notifications | #all-adaptco webhook |
| `PORT` | default 8000 | HTTP server port |
