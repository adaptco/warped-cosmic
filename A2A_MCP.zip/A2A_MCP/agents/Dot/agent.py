import os,json
from pathlib import Path
TASK_ID=os.environ.get("TASK_ID","T-008")
out_dir=Path("artifacts")/TASK_ID
out_dir.mkdir(parents=True,exist_ok=True)
result={"task_id":TASK_ID,"agent":"Dot","status":"dispatched"}
(out_dir/"result.json").write_text(json.dumps(result,indent=2))
print(f"[Dot] {TASK_ID} done")
