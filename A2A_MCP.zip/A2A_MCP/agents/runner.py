import os,sys,json,subprocess
from pathlib import Path
TASK_ID=os.environ["TASK_ID"]
AGENT_CARD=os.environ["AGENT_CARD"]
script=Path(__file__).parent.parent/AGENT_CARD
if not script.exists():
    out=Path("artifacts")/TASK_ID
    out.mkdir(parents=True,exist_ok=True)
    (out/"result.json").write_text(json.dumps({"task_id":TASK_ID,"status":"stub"}))
    sys.exit(0)
sys.exit(subprocess.run([sys.executable,str(script)],env=os.environ).returncode)
