import sys,json
from pathlib import Path
receipts_dir=Path(sys.argv[1]) if len(sys.argv)>1 else Path("receipts")
receipts=list(receipts_dir.glob("*.receipt.json"))
if not receipts: print("[Luma] No receipts yet"); sys.exit(0)
failures=[]
for f in receipts:
    r=json.loads(f.read_text())
    if r.get("gate")=="FAIL": failures.append(r["task_id"])
    else: print(f"[Luma] PASS {r['task_id']} cov={r['coverage']['coverage_pct']}%")
if failures: print(f"[Luma] GATE FAIL: {failures}"); sys.exit(1)
print("[Luma] All gates passed")
