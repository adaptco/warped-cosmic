import os,json
from pathlib import Path
TASK_ID=os.environ.get("TASK_ID","T-001")
out_dir=Path("artifacts")/TASK_ID
out_dir.mkdir(parents=True,exist_ok=True)
try:
    from anthropic import Anthropic
    client=Anthropic(api_key=os.environ["ANTHROPIC_API_KEY"])
    graph=json.load(open(Path(__file__).parent.parent.parent/"task-graph.a2a.json"))
    task=next(t for t in graph["tasks"] if t["task_id"]==TASK_ID)
    r=client.messages.create(model="claude-sonnet-4-20250514",max_tokens=2048,
        system="You are the Sovereign Orchestrator. Execute the A2A task.",
        messages=[{"role":"user","content":f"Execute: {json.dumps(task)}"}])
    result={"task_id":TASK_ID,"agent":"Claude","output":r.content[0].text}
except Exception as e:
    result={"task_id":TASK_ID,"agent":"Claude","error":str(e),"status":"stub"}
(out_dir/"result.json").write_text(json.dumps(result,indent=2))
print(f"[Claude] {TASK_ID} done")
