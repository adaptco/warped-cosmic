import os,sys,json,hmac,hashlib
from datetime import datetime,timezone
from pathlib import Path
TASK_ID=sys.argv[1] if len(sys.argv)>1 else os.environ.get("TASK_ID","T-001")
SECRET=os.environ.get("ECHO_RELAY_SECRET","")
artifacts_dir=Path(__file__).parent.parent.parent/"artifacts"
rp=artifacts_dir/TASK_ID/"result.json"
result=json.loads(rp.read_text()) if rp.exists() else {"task_id":TASK_ID}
env={"envelope_version":"1.0","task_id":TASK_ID,
    "from_agent":result.get("agent","system"),"to_agent":"Echo",
    "llm_hop":"agent->echo",
    "payload":{"artifact_id":f"{TASK_ID}/result.json","data":result},
    "timestamp":datetime.now(timezone.utc).isoformat(),"signature":None}
if SECRET:
    env["signature"]=hmac.new(SECRET.encode(),json.dumps(env,sort_keys=True).encode(),hashlib.sha256).hexdigest()
log=artifacts_dir/"echo-relay-log.jsonl"
log.parent.mkdir(parents=True,exist_ok=True)
with open(log,"a") as f: f.write(json.dumps(env)+"\n")
print(f"[Echo] Relayed {TASK_ID}")
